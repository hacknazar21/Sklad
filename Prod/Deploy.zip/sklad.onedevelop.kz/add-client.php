<?php
	$databaseHost = 'srv-pleskdb54.ps.kz:3306';
	$databaseUsername = 'onedevel_sklad';
	$databasePassword = '85Ei3_9zx';
	$databaseName = 'onedevel_sklad';

	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	$result = mysqli_query($mysqli, "INSERT INTO `Клиент`(`Имя`, `Компания`) VALUES ('". $_POST["client"]["name"] ."','". $_POST["client"]["company"] ."')");
	header("Location: /" );
	die();
?>