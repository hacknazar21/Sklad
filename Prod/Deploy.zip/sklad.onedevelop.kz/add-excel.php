<?php
	$databaseHost = 'srv-pleskdb54.ps.kz:3306';
	$databaseUsername = 'onedevel_sklad';
	$databasePassword = '85Ei3_9zx';
	$databaseName = 'onedevel_sklad';

	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	// упрощенная функция scandir
	function myscandir($dir)
	{
		$list = scandir($dir);
		unset($list[0],$list[1]);
		return array_values($list);
	}

	// функция очищения папки
	function clear_dir($dir)
	{
		$list = myscandir($dir);

		foreach ($list as $file)
		{
			if (is_dir($dir.$file))
			{
				clear_dir($dir.$file.'/');
				rmdir($dir.$file);
			}
			else
			{
				unlink($dir.$file);
			}
		}
	}
?>

<?php 
	$fileTmpPath = $_FILES['excel']['tmp_name'];
	$fileName = $_FILES['excel']['name'];
	$fileSize = $_FILES['excel']['size'];
	$fileType = $_FILES['excel']['type'];
	$fileNameCmps = explode(".", $fileName);
	$fileExtension = strtolower(end($fileNameCmps));
	
	clear_dir('./uploaded_files/');
	$newFileName = md5(time() . $fileName) . '.' . $fileExtension;
	$allowedfileExtensions = array('xlsx');
	if (in_array($fileExtension, $allowedfileExtensions)) {
		$uploadFileDir = './uploaded_files/';
		$dest_path = $uploadFileDir . $newFileName;
		if(move_uploaded_file($fileTmpPath, $dest_path))
		{
		  $message ='File is successfully uploaded.';
		}
		else
		{
		  $message = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
		}
	}
	echo $message;
	require_once __DIR__ . '/simple-xlsx/simplexlsx.class.php'; 

	$xlsx = new SimpleXLSX($dest_path);
	// Первый лист
	$sheet = $xlsx->rows(0);
	$iter = 14;
	while($sheet[$iter+1][0] !== NULL){
	   	$result = mysqli_query($mysqli, "INSERT INTO `Товар`( `ID_Клиента`, `Расположение`, `Штрих-код`, `Название`, `Дата приема`, `Срок годности`, `Количество`, `Фактическое количество`, `Масса`, `Артикул`, `Примечание`, `Принят`) VALUES ('". $_POST["add"]["ID"] ."','-','". $sheet[$iter][2] ."','". $sheet[$iter][3] ."','". date("Y-m-d") ."','-','". $sheet[$iter][4] ."','0','".  $sheet[$iter][5] ."','". $sheet[$iter][1] ."','". $sheet[$iter][7] ."','0')");
		$iter++;
	}
	header("Location: /reception.php?ID=". $_POST["add"]["ID"] ."" );
	die();
?>