		<?php include 'header.php';?>
		<?php 
			function template()
			{
				extract(func_get_arg(1));

				ob_start();

				if (file_exists(func_get_arg(0))) {
					require func_get_arg(0);
				} else {
					echo 'Template not found!';
				}

				return ob_get_clean();
			}
		?>
		<main class="page">
			<aside class="page__aside aside">
				<div class="aside__menu menu">
					<nav class="menu__body">
						<div class="menu__body-title">
							<p>Home</p>
						</div>
						<ul class="menu__list">
							<li class="menu-item">
								<a href="" class="menu-link active">
									<div class="menu-link__icon cubes">
										<span class="cubes__item"></span>
										<span class="cubes__item no-active"></span>
										<span class="cubes__item"></span>
										<span class="cubes__item"></span>
									</div>
									<div class="menu-link__text">
										<p>Dashboard</p>
									</div>
								</a>
							</li>
							<li class="menu-item">
								<a href="" class="menu-link ">
									<div class="menu-link__icon settings">
										<span class="settings__circle"></span>
										<span class="settings__line"></span>
										<span class="settings__line"></span>
										<span class="settings__circle"></span>
									</div>
									<div class="menu-link__text">
										<p>Menu Style</p>
									</div>
								</a>
							</li>
						</ul>

					</nav>
				</div>
			</aside>
			<section class="page__main main">
				<div class="main__head-cards">
					<a href="/reception.php" class="main__head-card head-card">
						<div class="head-card__title">Принять товар</div>
						<span></span>
						<div class="head-card__text">
							<p>
								Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat
								duis enim velit mollit.
							</p>
						</div>
					</a>
					<a href="/leave.php" class="main__head-card head-card">
						<div class="head-card__title">Отдать товар</div>
						<span></span>
						<div class="head-card__text">
							<p>
								Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat
								duis enim velit mollit.
							</p>
						</div>
					</a>
					<a href="" class="main__head-card head-card">
						<div class="head-card__title">Ревизия</div>
						<span></span>
						<div class="head-card__text">
							<p>
								Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat
								duis enim velit mollit.
							</p>
						</div>
					</a>
				</div>
				<div class="main__block-title">
					<p>Место на складе</p>
				</div>
				<div class="main__cards">
					<?php $chars = ['А','Б','В','Г','Д','Е','Ж','З'];?>
					<?php foreach($chars as $char):?>
						<?php $columns = 0; $rows = 0;?>
						<?php if($char === 'А' or $char === 'З'):?>
						<?php $columns = 46; $rows = 5;?>
						<?php elseif($char === 'Б'or $char === 'Ж'):?>
						<?php $columns = 48; $rows = 6;?>
						<?php elseif($char === 'В' or $char === 'Г' or $char === 'Д' or $char === 'Е' ):?>
						<?php $columns = 48; $rows = 7;?>
						<?php endif;?>
						<?php $all = $columns * $rows;?>
						<?php foreach($clients as $client):?>
						<?php foreach($products[$client["ID"]] as $product):?>
						<?php $coords = explode('-', $product["Расположение"]);//Фактическое количество?>  
						<?php if($coords[0] == $char):?>
						<?php if(!in_array($client, $IDs[$coords[1]][$coords[2]])):?>
						<?php $coordsColumns[] = $coords[1];?>
						<?php endif;?>
						<?php endif;?>
						<?php endforeach;?>
						<?php endforeach;?>
						<?php $forbidden = count(array_count_values($coordsColumns));?>
						<div class="main__card card normal">
							<div class="card__head">
								<div class="card__title">
									<p>СКЛАД</p>
								</div>
								<div class="card__subtitle">
									<p><?php echo $char;?></p>
								</div>
							</div>
							<div class="card__body">
								<div class="card__body-title">
									<p>Ячейки</p>
								</div>
								<div class="card__body-items">
									<div class="body-item">
										<div class="body-item__box">
											<div class="body-item__title">
												<p>Занято</p>
											</div>
											<div class="body-item__value">
												<p><?php echo $forbidden;?></p>
											</div>
										</div>
									</div>
									<div class="body-item">
										<div class="body-item__box">
											<div class="body-item__title">
												<p>Свободно</p>
											</div>
											<div class="body-item__value">
												<p><?php echo $all-$forbidden;?></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="main__footer">
								<a href="/cells.php?type=<?php echo $char;?>" class="main__footer-link">Смотреть детали</a>
							</div>
						</div>
					<?php unset($coordsColumns);endforeach;?>
				</div>
				<div class="main__block-title">
					<p>Клиенты</p>
				</div>
				<div class="main__cards">
					<?php
						foreach($clients as $client):
					?>
					<div class="main__card card normal">
						<div class="card__head">
							<div class="card__subtitle">
								<p><?php echo $client["Имя"];?></p>
							</div>
						</div>
						<div class="card__body">
							<div class="card__body-title">
								<p>Количество товара</p>
							</div>
							<div class="card__body-items">
								<div class="body-item">
									<div class="body-item__box">
										<div class="body-item__value">
											<?php 
												$all = 0;
												foreach($products[$client["ID"]] as $product){
												$all = $all + (int)$product["Фактическое количество"];
											} ?>
											<p>
												<?php echo $all;?>
											</p>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="main__footer">
							<a href="/profile.php?ID=<?php echo $client["ID"];?>" class="main__footer-link">Смотреть пользователя</a>
						</div>
					</div>
					<?php endforeach;?>
				</div>
				<button data-popup="#add_client" class="common-button">Добавить клиента</button>
			</section>
		</main>
		<div id="add_client" aria-hidden="true" class="popup">
			<div class="popup__wrapper">
				<div class="popup__content">
					<button data-close type="button" class="popup__close"></button>
					<div class="popup__text">
						<form action="/add-client.php" method="POST" class="popup-form">
							<div class="popup-form__inputs grid-2">
								<div class="popup-form__input-box">
									<label for="name">Имя</label>
									<input id="name" type="text" name="client[name]" class="popup-form__input">
								</div>
								<div class="popup-form__input-box">
									<label for="company">Компания</label>
									<input id="company" type="text" name="client[company]" class="popup-form__input">
								</div>
							</div>
							<button type="submit" class="popup-form__button common-button">Добавить клиента</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="js/app.min.js?_v=20220628171530"></script>
</body>

</html>