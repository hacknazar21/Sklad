<?php
	// Basic connection settings
	$databaseHost = 'srv-pleskdb54.ps.kz:3306';
	$databaseUsername = 'onedevel_sklad';
	$databasePassword = '85Ei3_9zx';
	$databaseName = 'onedevel_sklad';

	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	if (!$mysqli) {
		die('Ошибка соединения: ' . mysql_error());
	}
	$result = mysqli_query($mysqli, "SELECT * FROM `Клиент`");
	for ($clients = []; $row = mysqli_fetch_assoc($result); $clients[] = $row);
	
	foreach($clients as $client){
			$result = mysqli_query($mysqli, "SELECT * FROM `Товар` WHERE ID_Клиента = " . $client["ID"]);
			for ($products[$client["ID"]] = []; $row = mysqli_fetch_assoc($result); $products[$client["ID"]][] = $row);
	}
?>
<!DOCTYPE html>
<html lang="ru">

<head>
	<title>Прием товара</title>
	<meta charset="UTF-8">
	<meta name="format-detection" content="telephone=no">
	<!-- <style>body{opacity: 0;}</style> -->
	<link rel="stylesheet" href="css/style.min.css?_v=20220629104844">
	<link rel="shortcut icon" href="favicon.ico">
	<!-- <meta name="robots" content="noindex, nofollow"> -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
	<div class="wrapper">
		<header class="header">
			<div class="header__container">
				<div class="header__logo">
					<a href="/" class="logo line-under">
						<div class="logo_icon">
							<span class="logo_icon-item"></span>
							<span class="logo_icon-item"></span>
							<span class="logo_icon-item"></span>
							<span class="logo_icon-item"></span>
						</div>
						<div class="logo__name">
							<p>Sklad UI</p>
						</div>
					</a>
				</div>
				<div class="header__actions">
					<div class="header__search">
						<form class="header__search-form">
							<button type="submit" class="search-icon">
								<span class="search-icon__item"></span>
								<span class="search-icon__item"></span>
							</button>
							<div class="input-box">
								<input autocomplete="off" type="text" name="form[]" data-error="Ошибка" placeholder="" class="input" id="search">
								<label class="input-label" for="search">Search…</label>
							</div>
						</form>
					</div>
					<div class="header__profile">
						<div class="header__profile-avatar">
							<picture><source srcset="img/avatar.webp" type="image/webp"><img src="img/avatar.jpg" alt=""></picture>
						</div>
						<div class="header__profile-info">
							<div class="header__profile-name">Austin Robertson</div>
							<div class="header__profile-job">Marketing Administrator</div>
						</div>
					</div>
				</div>
			</div>
		</header>