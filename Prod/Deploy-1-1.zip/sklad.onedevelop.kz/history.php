		<?php include 'header.php';?>
		<?php $type = -1; $date = -1; 
			if($_POST){
				if($_POST["date"]){
					$date = $_POST["date"];
				}
				elseif($_POST["type"]){
					$type = $_POST["type"];
				}
			}
		?>
		<?php foreach($clients as $client): ?>
		<?php foreach($products[$client["ID"]] as $product): ?>
			<?php if($product["Выдача"]):?>
				<?php $avlDates[] = $product["Дата выдачи"];?>
			<?php elseif($product["Прием"]):?>
				<?php $avlDates[] = $product["Дата приема"];?>
			<?php endif;?>
		<?php endforeach;?>
		<?php endforeach;?>
		<main class="page">
			<aside class="page__aside aside">
				<div class="aside__menu menu">
					<nav class="menu__body">
						<div class="menu__body-title">
							<p>Home</p>
						</div>
						<ul class="menu__list">
							<li class="menu-item">
								<a href="" class="menu-link active">
									<div class="menu-link__icon cubes">
										<span class="cubes__item"></span>
										<span class="cubes__item no-active"></span>
										<span class="cubes__item"></span>
										<span class="cubes__item"></span>
									</div>
									<div class="menu-link__text">
										<p>Dashboard</p>
									</div>
								</a>
							</li>
							<li class="menu-item">
								<a href="" class="menu-link ">
									<div class="menu-link__icon settings">
										<span class="settings__circle"></span>
										<span class="settings__line"></span>
										<span class="settings__line"></span>
										<span class="settings__circle"></span>
									</div>
									<div class="menu-link__text">
										<p>Menu Style</p>
									</div>
								</a>
							</li>
						</ul>
					</nav>
				</div>
			</aside>
			<section class="page__main history">
				<div class="main__block-title">
					<p>История</p>
				</div>
				<div class="history__actions">
					<div class="history__seacr-form">
						<div class="popup-form__inputs grid-3">
							<div class="history-form__input-box">
								<button type="submit" class="search-icon">
									<span class="search-icon__item"></span>
									<span class="search-icon__item"></span>
								</button>
								<input autocomplete="off" type="text" name="form[]" data-error="Ошибка" placeholder="Поиск" class="input" id="search">
							</div>
							<form action="" method="POST" class="reception__select-box select-box">
								<select data-submit name="date" class="form">
									<?php if($date == -1):?>
										<option value="">Выбрать дату</option>
										<?php foreach(array_unique($avlDates) as $avlDate):?>
											<option value="<?php echo $avlDate;?>">
												<?php echo $avlDate;?>
											</option>
										<?php endforeach;?>
									<?php else:?>
										<?php foreach(array_unique($avlDates) as $avlDate):?>
											<?php if($avlDate == $date):?>
												<option value="<?php echo $avlDate;?>" selected>
													<?php echo $avlDate;?>
												</option>
											<?php else:?>
												<option value="<?php echo $avlDate;?>">
													<?php echo $avlDate;?>
												</option>
											<?php endif;?>
										<?php endforeach;?>
										<option value="-1">Сброс</option>
									<?php endif;?>
									
								</select>
							</form>
							<form action="" method="POST" class="reception__select-box select-box">
								<select data-submit name="type" class="form">
									<?php if($type == -1):?>
										<option value="">Тип операции</option>
										<option value="Выдача">
											Выдача
										</option>
										<option value="Прием">
											Прием
										</option>
									<?php elseif($type === "Выдача"):?>
										<option value="Выдача" selected>Выдача</option>
										<option value="Прием">Прием</option>
										<option value="-1">Сброс</option>
									<?php elseif($type === "Прием"):?>
										<option value="Прием" selected>Прием</option>
										<option value="Выдача">Выдача</option>
										<option value="-1">Сброс</option>
									<?php endif;?>
								</select>
							</form>
						</div>
					</div>
				</div>
				<form action="" class="profile__table">
					<table class="profile__table table" style="text-align: center;">
						<thead>
							<tr>
								<th>
									<h3>Номер</h3>
								</th>
								<th>
									<h3>Пользователь</h3>
								</th>
								<th>
									<h3>Дата </h3>
								</th>
								<th>
									<h3>Тип</h3>
								</th>
								<th>
									<h3>Наименование товара</h3>
								</th>
								<th>
									<h3>Количество товара</h3>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php $count=0;foreach($clients as $client): ?>
							<?php foreach($products[$client["ID"]] as $product): ?>
								<?php if($type == -1):?>
								<?php if($product["Выдача"] or $product["Прием"]):?>
									<?php if($date != -1 and ($product['Дата выдачи'] == $date or $product['Дата приема'] == $date)):?>
										<tr>
											<td>
												<?php echo $count++;?>
											</td>
											<td><?php echo $client["Имя"];?></td>
											<td>
												<?php echo $date;?>
											</td>
											<td>
												<?php if($product["Выдача"]):?>
												Выдача
												<?php elseif($product["Прием"]):?>
												Прием
												<?php endif;?>
											</td>
											<td>
												<input type="text" class="input-can-change-value " placeholder="<?php echo $product["Название"];?>" value="<?php echo $product["Название"];?>">
											</td>
											<td>
												<?php echo $product["Фактическое количество"];?> шт
											</td>
										</tr>
									<?php elseif($date == -1):?>
										<tr>
											<td>
												<?php echo $count++;?>
											</td>
											<td><?php echo $client["Имя"];?></td>
											<td>
												<?php if($product["Выдача"]):?>
													<?php echo $product["Дата выдачи"];?>
												<?php elseif($product["Прием"]):?>
													<?php echo $product["Дата приема"];?>
												<?php endif;?>
											</td>
											<td>
												<?php if($product["Выдача"]):?>
												Выдача
												<?php elseif($product["Прием"]):?>
												Прием
												<?php endif;?>
											</td>
											<td>
												<input type="text" class="input-can-change-value " placeholder="<?php echo $product["Название"];?>" value="<?php echo $product["Название"];?>">
											</td>
											<td>
												<?php echo $product["Фактическое количество"];?> шт
											</td>
										</tr>
									<?php endif;?>
									
								<?php endif; ?>
								<?php elseif($product[$type]):?>
										<tr>
											<td>
												<?php echo $count++;?>
											</td>
											<td><?php echo $client["Имя"];?></td>
											<td>
												<?php if($product["Выдача"]):?>
													<?php echo $product["Дата выдачи"];?>
												<?php elseif($product["Прием"]):?>
													<?php echo $product["Дата приема"];?>
												<?php endif;?>
											</td>
											<td>
												<?php echo $type;?>
											</td>
											<td>
												<input type="text" class="input-can-change-value " placeholder="<?php echo $product["Название"];?>" value="<?php echo $product["Название"];?>">
											</td>
											<td>
												<?php echo $product["Фактическое количество"];?> шт
											</td>
										</tr>
								<?php endif; ?>
							
							<?php endforeach; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
					<button type="submit" class="profile__button common-button">Сохранить</button>
				</form>
			</section>
		</main>
	</div>
	<script src="js/app.min.js?_v=20220629104844"></script>
</body>

</html>