
		<?php include 'header.php';?>
		<?php $clientID = -1; if($_POST){
				$clientID = $_POST["client"]["ID"];
			}
			else if($_GET){
				$clientID = $_GET["ID"];
			}
		?>
		<main class="page">
			<aside class="page__aside aside">
				<div class="aside__menu menu">
					<nav class="menu__body">
						<div class="menu__body-title">
							<p>Home</p>
						</div>
						<ul class="menu__list">
							<li class="menu-item">
								<a href="" class="menu-link active">
									<div class="menu-link__icon cubes">
										<span class="cubes__item"></span>
										<span class="cubes__item no-active"></span>
										<span class="cubes__item"></span>
										<span class="cubes__item"></span>
									</div>
									<div class="menu-link__text">
										<p>Dashboard</p>
									</div>
								</a>
							</li>
							<li class="menu-item">
								<a href="" class="menu-link ">
									<div class="menu-link__icon settings">
										<span class="settings__circle"></span>
										<span class="settings__line"></span>
										<span class="settings__line"></span>
										<span class="settings__circle"></span>
									</div>
									<div class="menu-link__text">
										<p>Menu Style</p>
									</div>
								</a>
							</li>
						</ul>

					</nav>
				</div>
			</aside>
			<section class="page__main reception">
				<div class="reception__back back">
					<a href="" class="back-link">Назад</a>
				</div>
				<div class="main__block-title">
					<p>Прием товара</p>
				</div>
				<form action="" method="POST" class="reception__select-box select-box">
					<select data-submit name="client[ID]" class="form">
						<?php if($clientID === -1):?>
							<option value="">Выбрать пользователя</option>
						<?php endif;?>
						<?php foreach($clients as $client): ?>
							<option value="<?php echo $client["ID"];?>" <?php if($clientID === $client["ID"]):?> selected <?php endif;?>>
								<?php echo $client["Имя"];?>
							</option>
						<?php endforeach; ?>
					</select>
				</form>
				<div class="reception__actions">
					<form action="add-excel.php" enctype="multipart/form-data" id="upload-form" method="POST" class="reception__file-upload file-upload">
						<input type="hidden" name="add[ID]" value="<?php echo $clientID; ?>" >
						<input type="file" name="excel" class="file-upload__input" id="upload">
						<label for="upload" class="file-upload__label">Загрузить Excel таблицу</label>
					</form>
					<script>
						document.getElementById("upload").onchange = function() {
							document.getElementById("upload-form").submit();
						};
					</script>
					<div class="reception__edit edit">
						<button data-popup="#popup_add" class="edit__button">Добавить данные</button>
					</div>
				</div>
				<div class="main__block-title">
					<p>Таблица товаров</p>
				</div>
				<form action="/add.php" method="POST" class="profile__table">
					
					<table class="profile__table table">
						<thead>
							
							<tr>
								<th>
									<h3>Номер</h3>
								</th>
								<th>
									<h3>Артикул</h3>
								</th>
								<th>
									<h3>Наименование товара</h3>
								</th>
								<th>
									<h3>Кол-во товара</h3>
								</th>
								<th>
									<h3>Масса всей позициии</h3>
								</th>
								<th>
									<h3>Срок годности</h3>
								</th>
								<th>
									<h3>Примечание</h3>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php if($clientID !== -1): $count = 1;?>
							<?php foreach($products[$clientID] as $product): ?>
							<?php if(!$product["Прием"]):?>
								<input type="hidden" name="add[ID][]" value="<?php echo $product["ID"]; ?>" >
								<tr>
									<td class="center">
										<?php echo $count++;?>
									</td>
									<td>
										<?php echo $product["Артикул"];?>
									</td>
									<td>
										<input type="text" class="input-can-change-value" name="add[name][]" placeholder="<?php echo $product["Название"];?>" value="<?php echo $product["Название"];?>">
									</td>
									<td><?php echo $product["Количество"];?> шт</td>
									<td><?php echo $product["Масса"];?> кг</td>
									<td>
										<input type="text" name="add[shelf][]" class="input-can-change-value" placeholder="<?php echo $product["Срок годности"];?>" value="<?php echo $product["Срок годности"];?>">
									</td>
									<td>
										<input type="text" name="add[note][]" class="input-can-change-value" placeholder="<?php echo $product["Примечание"];?>" value="<?php echo $product["Примечание"];?>">
									</td>
								</tr>
							<?php endif; ?>
							<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
					<button type="submit" name="add[save]" value="1" class="profile__button common-button">Сохранить</button>
				</form>
			</section>
		</main>
		<footer class="footer">
			<div class="footer__container">
			</div>
		</footer>
	</div>
	<div id="popup_add" aria-hidden="true" class="popup">
		<div class="popup__wrapper">
			<div class="popup__content">
				<button data-close type="button" class="popup__close"></button>
				<div class="popup__text">
					<form action="/add.php" method="POST" class="popup-form">
						<input type="hidden" name="add[ID]" value="<?php echo $clientID; ?>" >
						<div class="popup-form__inputs grid-2">
							<div class="popup-form__input-box">
								<label for="article">Артикул</label>
								<input id="article" type="text" name="add[article]" class="popup-form__input">
							</div>
							<div class="popup-form__input-box">
								<label for="name">Наименование товара</label>
								<input id="name" type="text" name="add[name]" class="popup-form__input">
							</div>
						</div>
						<div class="popup-form__inputs grid-3">
							<div data-units="ед" class="popup-form__input-box">
								<label for="quantity">Количество товара</label>
								<input id="quantity" type="text" name="add[quantity]" class="popup-form__input">
							</div>
							<div data-units="кг" class="popup-form__input-box">
								<label for="weight">Масса всей позиции</label>
								<input id="weight" type="text" name="add[weight]" class="popup-form__input">
							</div>
							<div data-units="мес" class="popup-form__input-box">
								<label for="shelf">Срок годности</label>
								<input id="shelf" type="text" name="add[shelf]" class="popup-form__input">
							</div>
						</div>
						<div class="popup-form__inputs grid-1">
							<div class="popup-form__input-box">
								<label for="note">Примечание</label>
								<textarea id="note" type="text" name="add[note]" class="popup-form__input"></textarea>
							</div>
						</div>
						<button type="submit" name="add[save]" value="0" class="popup-form__button common-button">Добавить позицию</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<script src="js/app.min.js?_v=20220629104844"></script>
</body>

</html>