		<?php include 'header.php';?>
		<?php 
			
			if($_GET){
				$name = '';
				$company = '';
				foreach($clients as $client){
					if($client["ID"] === $_GET["ID"]){
						$name = $client["Имя"];
						$company = $client["Компания"];
						break;
					}
				}
			}
		?>
		<main class="page">
			<aside class="page__aside aside">
				<div class="aside__menu menu">
					<nav class="menu__body">
						<div class="menu__body-title">
							<p>Home</p>
						</div>
						<ul class="menu__list">
							<li class="menu-item">
								<a href="" class="menu-link active">
									<div class="menu-link__icon cubes">
										<span class="cubes__item"></span>
										<span class="cubes__item no-active"></span>
										<span class="cubes__item"></span>
										<span class="cubes__item"></span>
									</div>
									<div class="menu-link__text">
										<p>Dashboard</p>
									</div>
								</a>
							</li>
							<li class="menu-item">
								<a href="" class="menu-link ">
									<div class="menu-link__icon settings">
										<span class="settings__circle"></span>
										<span class="settings__line"></span>
										<span class="settings__line"></span>
										<span class="settings__circle"></span>
									</div>
									<div class="menu-link__text">
										<p>Menu Style</p>
									</div>
								</a>
							</li>
						</ul>

					</nav>
				</div>
			</aside>
			<section class="page__main profile">
				<div class="profile__back back">
					<a href="" class="back-link">Назад</a>
				</div>
				<div class="main__block-title">
					<p>Профиль клиента</p>
				</div>
				<div class="profile__info-box">
					<div class="main__card card  blue-top">
						<div class="card__head no-bb">
							<div class="card__title">
								<p>Фамилия и имя</p>
							</div>
							<div class="card__subtitle no-mb">
								<p><?php echo $name;?></p>
							</div>
						</div>
						<div class="card__head no-bb">
							<div class="card__title">
								<p>Компания</p>
							</div>
							<div class="card__subtitle no-mb">
								<p><?php echo $company;?></p>
							</div>
						</div>
					</div>
					<div class="main__card card  blue-top">
						<div class="card__head no-bb no-mb">
							<div class="card__title no-mb">
								<p>Товар</p>
							</div>
						</div>
						<div class="card__body no-bb">
							<div class="card__body-items">
								<div class="body-item green-left">
									<div class="body-item__box">
										<div class="body-item__title">
											<p>Количество товара</p>
										</div>
										<div class="body-item__value">
											<?php 
												$all = 0;
												foreach($products[$_GET["ID"]] as $product){
												$all = $all + (int)$product["Фактическое количество"];
											} ?>
											<p><?php echo $all;?> шт</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<form action="" class="profile__table">
					<table class="profile__table table">
						<thead>
							<tr>
								<th>
									<h3>Выбрать</h3>
								</th>
								<th>
									<h3>Расположение</h3>
								</th>
								<th>
									<h3>Штрихкод</h3>
								</th>
								<th>
									<h3>Наименование товара</h3>
								</th>
								<th>
									<h3>Дата приема </h3>
								</th>
								<th>
									<h3>Срок годности товара</h3>
								</th>
								<th>
									<h3>Кол-во товара</h3>
								</th>
								<th>
									<h3>Профиль</h3>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($products[$_GET["ID"]] as $product): ?>
							<tr>
								<td class="center">
									<input type="checkbox" class="table-checkbox-input" id="table-checkbox-input_<?php echo $product["ID"];?>">
									<label for="table-checkbox-input_<?php echo $product["ID"];?>"></label>
								</td>
								<td><?php echo $product["Расположение"];?></td>
								<td><?php echo (int)$product["Штрих-код"];?></td>
								<td>
									<input type="text" class="input-can-change-value " id="input-can-change-value_1" placeholder="<?php echo $product["Название"];?>">
								</td>
								<td>
									<input type="text" class="input-can-change-value " id="input-can-change-value_1" placeholder="<?php echo $product["Дата приема"];?>">
								</td>
								<td>
									<input type="text" class="input-can-change-value " id="input-can-change-value_1" placeholder="<?php echo $product["Срок годности"];?>">
								</td>
								<td><?php echo $product["Фактическое количество"] == '0' ? $product["Количество"] : $product["Фактическое количество"];?> шт</td>
								<td>
									<button class="table-button">Выписать товар</button>
								</td>
							</tr>
							<?php endforeach;?>
						</tbody>
					</table>
					<button type="submit" class="profile__button common-button">Выписать позиции</button>
				</form>
			</section>
		</main>
		<footer class="footer">
			<div class="footer__container">
			</div>
		</footer>
	</div>
	<script src="js/app.min.js?_v=20220629104844"></script>
</body>

</html>