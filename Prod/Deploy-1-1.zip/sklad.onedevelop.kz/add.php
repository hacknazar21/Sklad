<?php
	$databaseHost = 'srv-pleskdb54.ps.kz:3306';
	$databaseUsername = 'onedevel_sklad';
	$databasePassword = '85Ei3_9zx';
	$databaseName = 'onedevel_sklad';

	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 

	if($_POST["add"]["save"]) {
		$iter = 0;
		foreach($_POST["add"]["ID"] as $ID){
			$result = mysqli_query($mysqli, "UPDATE `Товар` SET `Название`='". $_POST["add"]["name"][$iter] ."', `Срок годности`='". $_POST["add"]["shelf"][$iter] ."', `Примечание`='". $_POST["add"]["note"][$iter] ."', `Прием`='". $_POST["add"]["save"] ."' WHERE `ID`=" . $ID);
		$iter++;
		}
		header("Location: /reception.php" );
	}
	else {
		$result = mysqli_query($mysqli, "INSERT INTO `Товар`( `ID_Клиента`, `Расположение`, `Штрих-код`, `Название`, `Дата приема`, `Срок годности`, `Количество`, `Фактическое количество`, `Масса`, `Артикул`, `Примечание`, `Прием`) VALUES ('". $_POST["add"]["ID"] ."','-','-','". $_POST["add"]["name"] ."','". date("Y-m-d") ."','". $_POST["add"]["shelf"] ."','". $_POST["add"]["quantity"] ."','0','". $_POST["add"]["weight"] ."','". $_POST["add"]["article"] ."','". $_POST["add"]["note"] ."','". $_POST["add"]["save"] ."')");
		header("Location: /reception.php?ID=". $_POST["add"]["ID"] ."" );
		die();
	}
	
?>