		<?php include 'header.php';?>
		<?php if($_GET): ?>
		<?php $type = $_GET["type"]; endif;?>
		<?php $columns = 0; $rows = 0;?>
		<?php if($type === 'А' or $type === 'З'):?>
		<?php $columns = 46; $rows = 5;?>
		<?php elseif($type === 'Б'or $type === 'Ж'):?>
		<?php $columns = 48; $rows = 6;?>
		<?php elseif($type === 'В' or $type === 'Г' or $type === 'Д' or $type === 'Е' ):?>
		<?php $columns = 48; $rows = 7;?>
		<?php endif;?>
		<?php $all = $columns * $rows;?>
		<?php foreach($clients as $client):?>
		<?php foreach($products[$client["ID"]] as $product):?>
		<?php if(!$product["Выдача"] and $product["Расположение"] != '-'): ?>
		<?php $coords = explode('-', $product["Расположение"]);//Фактическое количество?>  
		<?php if($coords[0] == $type):?>
		<?php if(!in_array($client, $IDs[$coords[1]][$coords[2]])):?>
		<?php $coordsColumns[] = $coords[1];?>
		<?php $coordsRows[] = $coords[2];?>
		<?php $IDs[$coords[1]][$coords[2]][] = $client;?>
		<?php endif;?>
		<?php $quantity[$coords[1]][$coords[2]] += (int)$product["Фактическое количество"];?>
		<?php $productEach[$coords[1]][$coords[2]][$client["ID"]][] = $product;?>
		<?php endif;?>
		<?php endif;?>
		<?php endforeach;?>
		<?php endforeach;?>
		<main class="page">
			<aside class="page__aside aside">
				<div class="aside__menu menu">
					<nav class="menu__body">
						<div class="menu__body-title">
							<p>Home</p>
						</div>
						<ul class="menu__list">
							<li class="menu-item">
								<a href="" class="menu-link active">
									<div class="menu-link__icon cubes">
										<span class="cubes__item"></span>
										<span class="cubes__item no-active"></span>
										<span class="cubes__item"></span>
										<span class="cubes__item"></span>
									</div>
									<div class="menu-link__text">
										<p>Dashboard</p>
									</div>
								</a>
							</li>
							<li class="menu-item">
								<a href="" class="menu-link ">
									<div class="menu-link__icon settings">
										<span class="settings__circle"></span>
										<span class="settings__line"></span>
										<span class="settings__line"></span>
										<span class="settings__circle"></span>
									</div>
									<div class="menu-link__text">
										<p>Menu Style</p>
									</div>
								</a>
							</li>
						</ul>
					</nav>
				</div>
			</aside>
			<section class="page__main reception">
				<div class="reception__back back">
					<a href="" class="back-link">Назад</a>
				</div>
				<div class="main__card card normal df">
					<div class="card__head">
						<div class="card__title">
							<p>СКЛАД</p>
						</div>
						<div class="card__subtitle">
							<p><?php echo $type?> Ряд</p>
						</div>
					</div>
					<div class="card__body">
						<div class="card__body-items">
							<div class="body-item">
								<?php $forbidden = count(array_count_values($coordsColumns));?>
								<div class="body-item__box">
									<div class="body-item__title">
										<p>Занято</p>
									</div>
									<div class="body-item__value">
										<p>
											<?php echo $forbidden;?>
										</p>
									</div>
								</div>
							</div>
							<div class="body-item">
								<div class="body-item__box">
									<div class="body-item__title">
										<p>Свободно</p>
									</div>
									<div class="body-item__value">
										<p><?php echo $all - $forbidden;?></p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="cells__table-box">
					<table id="scroll-table" class="cells__table table">
						<thead>
							<tr>
								<th>
									<h3>Уровень</h3>
								</th>
								<?php $count=0; while($columns !== $count++):?>
								<th>
									<h3>
										<span><?php echo $count;?></span>
									</h3>
								</th>
								<?php endwhile;?>
							</tr>
						</thead>
						<tbody>
							<?php $countPopup = 0;?>
							<?php $count=0; while($rows !== $count++):?>
								<tr>
									<td class="center">
										<span>
											<?php echo $count;?>
										</span>
										Высота
									</td>
									<?php $countCol=0; while($columns !== $countCol++):?>
										<?php ?>
										<?php if(in_array($countCol, $coordsColumns) and in_array($count, $coordsRows) and array_search($countCol, $coordsColumns) == array_search($count, $coordsRows) ):?>
											<?php $countClient = array_count_values($coordsColumns)[$countCol];?>
											<?php $cells[] = array($countCol, $count);?>
											<td>
												<div data-popup="#popup_cell_<?php echo $countPopup++;?>" class="table__cell-item cell-item">
													<div class="cell-item__box">
														<div class="cell-item__images">
															<span><?php echo $countClient;?> клиентов</span>
														</div>
														<div class="cell-item__text">
															<div class="cell-item__title">Количество</div>
															<div class="cell-item__subtitle">
																<?php echo $quantity[$countCol][$count]?> шт
															</div>
														</div>
													</div>
												</div>
											</td>
										<?php else:?>
											<td>
												Свободно
											</td>
										<?php endif;?>
									<?php endwhile;?>
								</tr>
							<?php endwhile;?>
						</tbody>
					</table>
				</div>
			</section>
		</main>
		<footer class="footer">
			<div class="footer__container">
			</div>
		</footer>
	</div>
<?php $countPopup = 0;?>
<?php foreach($cells as $cell):?>
	<div id="popup_cell_<?php echo $countPopup++;?>" aria-hidden="true" class="popup">
		<div class="popup__wrapper">
			<div class="popup__content">
				<button data-close type="button" class="popup__close"></button>
				<div class="popup__text">
					<div data-spollers class="popup__spollers spollers">
						<?php foreach($IDs[$cell[0]][$cell[1]] as $ID):?>
						<div class="spollers__item">
							<div class="spollers__name">
								<span><?php echo $ID["Имя"];?></span>
								<a href="/profile.php?ID=<?php echo $ID["ID"];?>">Смотреть профиль</a>
							</div>
							<button type="button" data-spoller class="spollers__title">
								<?php $countQ = 0;?>
								<?php foreach($productEach[$cell[0]][$cell[1]][$ID["ID"]] as $product):?>
									<?php $countQ += $product['Фактическое количество'];?>
								<?php endforeach;?>
								<div class="spollers__quantity-box quantity-box">
									<div class="quantity-box__info">
										<div class="quantity-box__number"><?php echo $countQ;?></div>
										<div class="quantity-box__text">Товаров</div>
									</div>
								</div>
							</button>
							<div class="spollers__body">
								<form action="" class="profile__table">
									<table class="profile__table table">
										<thead>
											<tr>

												<th>
													<h3>Номер</h3>
												</th>
												<th>
													<h3>Наименование товара</h3>
												</th>
												<th>
													<h3>Дата приема</h3>
												</th>
												<th>
													<h3>Кол-во товара</h3>
												</th>
												<th>
													<h3>Профиль</h3>
												</th>
											</tr>
										</thead>
										<tbody>
											<?php $countRows = 1;?>
											<?php foreach($productEach[$cell[0]][$cell[1]][$ID["ID"]] as $product):?>
												<tr>
													<td>
														<?php echo $countRows++;?>
													</td>
													<td>
														<input type="text" class="input-can-change-value" placeholder="<?php echo $product["Название"];?>">
													</td>
													<td>
														<?php echo $product["Дата приема"];?>
													</td>
													<td><?php echo $product["Фактическое количество"];?> шт</td>
													<td>
														<button class="table-button">Выписать товар</button>
													</td>
												</tr>
											<?php endforeach;?>
										</tbody>
									</table>
									<button type="submit" class="profile__button common-button">Сохранить</button>
								</form>
							</div>
						</div>
						<?php endforeach;?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php endforeach;?>
	<script src="js/app.min.js?_v=20220629104844"></script>
</body>

</html>