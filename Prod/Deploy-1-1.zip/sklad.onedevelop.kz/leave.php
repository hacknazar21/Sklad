		<?php include 'header.php';?>
		<?php $clientID = -1; if($_POST){
				$clientID = $_POST["client"]["ID"];
			}
			else if($_GET){
				$clientID = $_GET["ID"];
			}
		?>
		<main class="page">
			<aside class="page__aside aside">
				<div class="aside__menu menu">
					<nav class="menu__body">
						<div class="menu__body-title">
							<p>Home</p>
						</div>
						<ul class="menu__list">
							<li class="menu-item">
								<a href="" class="menu-link active">
									<div class="menu-link__icon cubes">
										<span class="cubes__item"></span>
										<span class="cubes__item no-active"></span>
										<span class="cubes__item"></span>
										<span class="cubes__item"></span>
									</div>
									<div class="menu-link__text">
										<p>Dashboard</p>
									</div>
								</a>
							</li>
							<li class="menu-item">
								<a href="" class="menu-link ">
									<div class="menu-link__icon settings">
										<span class="settings__circle"></span>
										<span class="settings__line"></span>
										<span class="settings__line"></span>
										<span class="settings__circle"></span>
									</div>
									<div class="menu-link__text">
										<p>Menu Style</p>
									</div>
								</a>
							</li>
						</ul>

					</nav>
				</div>
			</aside>
			<section class="page__main reception">
				<div class="reception__back back">
					<a href="" class="back-link">Назад</a>
				</div>
				<div class="main__block-title">
					<p>Отпуск товара</p>
				</div>
				<form action="" method="POST" class="reception__select-box select-box">
					<select data-submit name="client[ID]" class="form">
						<?php if($clientID === -1):?>
							<option value="">Выбрать пользователя</option>
						<?php endif;?>
						<?php foreach($clients as $client): ?>
							<option value="<?php echo $client["ID"];?>" <?php if($clientID === $client["ID"]):?> selected <?php endif;?>>
								<?php echo $client["Имя"];?>
							</option>
						<?php endforeach; ?>
					</select>
				</form>
				<div class="reception__actions">
					<div class="reception__file-upload file-upload">
						<input type="file" name="" class="file-upload__input" id="upload">
						<label for="upload" class="file-upload__label">Загрузить Excel таблицу</label>
					</div>
				</div>
				<div class="main__block-title">
					<p>Товары пользователя</p>
				</div>
				<form action="/leave-form.php" method="POST" class="profile__table">
					<table class="profile__table table" style="text-align:center;">
						<thead>
							<tr>
								<th >
									<h3>Выбрать</h3>
								</th>
								<th>
									<h3>Номер</h3>
								</th>
								<th>
									<h3>Артикул</h3>
								</th>
								<th>
									<h3>Наименование товара</h3>
								</th>
								<th>
									<h3>Кол-во товара</h3>
								</th>
							</tr>
						</thead>
						<tbody>
							<?php if($clientID !== -1): $count = 1;?>
							<?php foreach($products[$clientID] as $product): ?>
								<?php if(!$product["Выдача"]):?>
								<tr>
									<td class="center">
										<input type="checkbox" name="leave[]" value="<?php echo $product["ID"];?>" class="table-checkbox-input" id="table-checkbox-input_<?php echo $count;?>">
										<label for="table-checkbox-input_<?php echo $count;?>"></label>
									</td>
									<td >
										<?php echo $count++;?>
									</td>
									<td>
										<?php echo $product["Артикул"];?>
									</td>
									<td>
										<input type="text" class="input-can-change-value" placeholder="<?php echo $product["Название"];?>">
									</td>
									<td><?php echo $product["Количество"];?> шт</td>
								</tr>
							<?php endif; ?>
							<?php endforeach; ?>
							<?php endif; ?>
						</tbody>
					</table>
					<button type="submit" class="profile__button common-button">Сохранить</button>
				</form>
			</section>
		</main>
		<footer class="footer">
			<div class="footer__container">
			</div>
		</footer>
	</div>
	<script src="js/app.min.js?_v=20220629104844"></script>
</body>

</html>