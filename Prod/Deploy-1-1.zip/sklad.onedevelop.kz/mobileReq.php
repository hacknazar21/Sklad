<?php
	// Basic connection settings
	$databaseHost = 'srv-pleskdb54.ps.kz:3306';
	$databaseUsername = 'onedevel_sklad';
	$databasePassword = '85Ei3_9zx';
	$databaseName = 'onedevel_sklad';

	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	if (!$mysqli) {
		die('Ошибка соединения: ' . mysql_error());
	}
	
	if($_GET) {
		if($_GET['type'] == 'getAll'){
			$result = mysqli_query($mysqli, "SELECT * FROM `Клиент`");
			for ($clients = []; $row = mysqli_fetch_assoc($result); $clients[] = $row);
			$result = mysqli_query($mysqli, "SELECT * FROM `Товар` WHERE `Расположение`='-'");
			for ($products = []; $row = mysqli_fetch_assoc($result); $products[] = $row);
			foreach ($products as $product) {
					$avlIDs[$product["ID_Клиента"]] = 0;
			}
		  echo json_encode(array('Clients'=>$clients, 'IDs'=>$avlIDs, 'Products'=>$products));
		}
		elseif($_GET['type'] == 'getLeave'){
			$result = mysqli_query($mysqli, "SELECT * FROM `Клиент`");
			for ($clients = []; $row = mysqli_fetch_assoc($result); $clients[] = $row);
			$result = mysqli_query($mysqli, "SELECT * FROM `Товар` WHERE `Расположение`!='-'");
			for ($products = []; $row = mysqli_fetch_assoc($result); $products[] = $row);
			foreach ($products as $product) {
					$avlIDs[$product["ID_Клиента"]] = 0;
			}
		  echo json_encode(array('Clients'=>$clients, 'IDs'=>$avlIDs, 'Products'=>$products));
		}
		elseif($_GET['scan']){
		  	$result = mysqli_query($mysqli, "SELECT * FROM `Товар` WHERE `Штрих-код`=".$_GET['scan']);
			for ($products = []; $row = mysqli_fetch_assoc($result); $products[] = $row);
			echo json_encode($products[0]);
		}
		elseif($_GET['place'] and $_GET['number'] and $_GET['shift'] and $_GET['ID']){
		  	$result = mysqli_query($mysqli, "UPDATE `Товар` SET `Расположение`='". $_GET['place'] ."',`Срок годности`='". $_GET['shift'] ."',`Фактическое количество`='". $_GET['number'] ."' WHERE `ID`=".$_GET['ID']);
			echo json_encode(array('status'=>'ok'));
		}
		elseif($_GET['dateleave'] and $_GET['ID']){
		  	$result = mysqli_query($mysqli, "UPDATE `Товар` SET  `Расположение`='-', `Дата выдачи`='". $_GET['dateleave'] ."' WHERE `ID`=".$_GET['ID']);
			echo json_encode(array('status'=>'ok'));
		}
	}
	die();
?>