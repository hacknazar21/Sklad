<?php
	$databaseHost = 'srv-pleskdb54.ps.kz:3306';
	$databaseUsername = 'onedevel_sklad';
	$databasePassword = '85Ei3_9zx';
	$databaseName = 'onedevel_sklad';

	$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
	foreach($_POST["leave"] as $ID){
		$result = mysqli_query($mysqli, "UPDATE `Товар` SET `Выдача`='1' WHERE `ID`=" . $ID);
	}
	header("Location: /leave.php" );
	die();
?>